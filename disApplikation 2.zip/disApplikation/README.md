Hej og velkommen til...

For at kunne eksekvere webapplikationen skal nedenstående kører i terminalen:
- npm install
- npm install express
- npm install express-session
- node / nodemon index.js